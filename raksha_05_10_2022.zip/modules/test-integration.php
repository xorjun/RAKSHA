<?php
// Test Integration

// CSS Style
echo '
<style>
#psec_confbox {
    position: absolute;
    border-style: solid;
    border-color: black;
    border-width: 2px;
    background-color: #87CEEB;
    text-align: center;
    color: black;
    font-size: large;
    width: 100%;
	z-index: 99999;
}
</style>';

// HTML Confirmation Message
echo '<p id="psec_confbox">This Website is Protected by <a href="https://zenter.in/s" target="_blank">RAKSHA.</a></p>';
?>